package com.example.acer.barber3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageButton;
import android.view.View;
import android.widget.ImageView;


public class MainActivity extends AppCompatActivity {


    ImageButton info_image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        info_image = findViewById(R.id.info_button);

        info_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentLoadNewActivity = new Intent(MainActivity.this, Main_info.class);
                startActivity(intentLoadNewActivity);
            }
        });


    }
}
